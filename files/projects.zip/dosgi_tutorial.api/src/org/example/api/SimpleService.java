package org.example.api;

public interface SimpleService {
	String timeNow();
}
