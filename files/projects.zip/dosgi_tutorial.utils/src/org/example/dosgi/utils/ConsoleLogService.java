package org.example.dosgi.utils;

import java.text.MessageFormat;

import org.osgi.framework.Constants;
import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogService;

public class ConsoleLogService implements LogService {
	
	private static String logLevelToString(int level) {
		final String result;
		switch (level) {
		case LogService.LOG_DEBUG:
			result = "DEBUG"; break;
		case LogService.LOG_INFO:
			result = "INFO"; break;
		case LogService.LOG_WARNING:
			result = "WARNING"; break;
		case LogService.LOG_ERROR:
			result = "ERROR"; break;
		default:
			result = "UNKNOWN";
		}
		return result;
	}

	@Override
	public void log(int level, String message) {
		System.out.println(MessageFormat.format("{0} --> {1}", logLevelToString(level), message));
	}

	@Override
	public void log(int level, String message, Throwable exception) {
		System.out.println(MessageFormat.format("{0} --> {1}: {2}", logLevelToString(level), message, exception != null ? exception.getClass() : null));
		if(exception != null) exception.printStackTrace();
	}

	@Override
	public void log(ServiceReference sr, int level, String message) {
		System.out.println(MessageFormat.format("{0} Service {1} --> {2}", logLevelToString(level), sr.getProperty(Constants.SERVICE_ID), message));
	}

	@Override
	public void log(ServiceReference sr, int level, String message, Throwable exception) {
		System.out.println(MessageFormat.format("{0} Service {1} --> {2}: {3}", logLevelToString(level), sr.getProperty(Constants.SERVICE_ID), message, exception != null ? exception.getClass() : null));
		if(exception != null) exception.printStackTrace();
	}

}
