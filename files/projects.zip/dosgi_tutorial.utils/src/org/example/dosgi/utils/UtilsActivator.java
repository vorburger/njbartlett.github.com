package org.example.dosgi.utils;

import org.eclipse.ecf.osgi.services.discovery.IHostDiscoveryListener;
import org.eclipse.ecf.osgi.services.discovery.IProxyDiscoveryListener;
import org.eclipse.ecf.osgi.services.discovery.LoggingHostDiscoveryListener;
import org.eclipse.ecf.osgi.services.discovery.LoggingProxyDiscoveryListener;
import org.eclipse.ecf.osgi.services.distribution.IHostDistributionListener;
import org.eclipse.ecf.osgi.services.distribution.IProxyDistributionListener;
import org.eclipse.ecf.osgi.services.distribution.LoggingHostDistributionListener;
import org.eclipse.ecf.osgi.services.distribution.LoggingProxyDistributionListener;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.service.log.LogService;

public class UtilsActivator implements BundleActivator {

	@Override
	public void start(BundleContext context) throws Exception {
		context.registerService(LogService.class.getName(), new ConsoleLogService(), null);
		
		context.registerService(IHostDistributionListener.class.getName(), new LoggingHostDistributionListener(), null);
		context.registerService(IHostDiscoveryListener.class.getName(), new LoggingHostDiscoveryListener(), null);
		
		context.registerService(IProxyDiscoveryListener.class.getName(), new LoggingProxyDiscoveryListener(), null);
		context.registerService(IProxyDistributionListener.class.getName(), new LoggingProxyDistributionListener(), null);
	}

	@Override
	public void stop(BundleContext context) throws Exception {
	}

}
