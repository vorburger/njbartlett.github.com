package org.example.foo;

import aQute.bnd.annotation.component.Component;

@Component(properties = "service.exported.interfaces=*," +
		"service.exported.configs=org.apache.cxf.ws")
public class FooRunnable implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
