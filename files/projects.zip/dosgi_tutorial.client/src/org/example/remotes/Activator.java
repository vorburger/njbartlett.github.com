package org.example.remotes;

import org.example.api.AuctionService;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.util.tracker.ServiceTracker;

public class Activator implements BundleActivator {

	private ServiceTracker tracker;

	@Override
	public void start(BundleContext context) throws Exception {
		tracker = new ServiceTracker(context, AuctionService.class.getName(), null);
		tracker.open();
	}
	@Override
	public void stop(BundleContext context) throws Exception {
		tracker.close();
	}
}
